package messenger.iti;

import androidx.appcompat.app.AppCompatActivity;
import androidx.fragment.app.Fragment;
import androidx.fragment.app.FragmentManager;
import androidx.fragment.app.FragmentTransaction;

import android.content.Intent;
import android.os.Bundle;
import android.util.Log;
import android.widget.FrameLayout;
import android.widget.Toast;

import com.ismaeldivita.chipnavigation.ChipNavigationBar;

import messenger.iti.fragments.ContactsFragment;
import messenger.iti.fragments.MessageFragment;
import messenger.iti.fragments.WaitingMessageFragment;

public class MainActivity extends AppCompatActivity {
   private ChipNavigationBar chipNavigationBar;
    private FragmentManager fragmentManager;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        initComponent();
        if(savedInstanceState==null) {
            chipNavigationBar.setItemSelected(R.id.item1,true);
            fragmentManager = getSupportFragmentManager();
            MessageFragment messageFragment = new MessageFragment();
            fragmentManager.beginTransaction()
                    .replace(R.id.fragment_container , messageFragment)
                    .commit();
        }
        chipNavigationBar.setOnItemSelectedListener(new ChipNavigationBar.OnItemSelectedListener() {
            @Override
            public void onItemSelected(int i) {
                 Fragment fragment=null;
                switch (i) {
                    case R.id.item1:
                        fragment = new MessageFragment();
                        break;
                    case R.id.item2:
                        fragment = new WaitingMessageFragment();
                        break;
                    case R.id.item3:
                        fragment = new ContactsFragment();
                        break;
                }
                if (fragment != null) {
                    fragmentManager = getSupportFragmentManager();
                    fragmentManager.beginTransaction()
                            .replace(R.id.fragment_container, fragment)
                            .commit();
                } else {
                    Toast.makeText(MainActivity.this, "error!!!!", Toast.LENGTH_SHORT).show();
                }

            }
        });
    }
            public void initComponent() {
                chipNavigationBar = findViewById(R.id.menu_Navigation);
            }
        }
