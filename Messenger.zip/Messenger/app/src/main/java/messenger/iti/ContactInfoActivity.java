package messenger.iti;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;

import messenger.iti.adapters.RecyclerViewAdapter;
import messenger.iti.fragments.ContactsFragment;
import messenger.iti.helpers.DataBaseHelper;

public class ContactInfoActivity extends AppCompatActivity  {
private TextView nameTextView,numberTextView;
private Button buttonDelete,buttonSendMessage;
private DataBaseHelper dataBaseHelper;
public static final String NUMBER_KEY="number key";
public static final String NAME_KEY="name key";

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_contact_info);
        initComponents();
        dataBaseHelper=new DataBaseHelper(this);
        Intent intent=getIntent();
        String name=intent.getStringExtra(ContactsFragment.KEY_NAME);
        final String number=intent.getStringExtra(ContactsFragment.KEY_NUMBER);
        nameTextView.setText(name);
        numberTextView.setText(number);
        buttonDelete.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                dataBaseHelper.deleteContact(number);
                finish();
            }
        });
        buttonSendMessage.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent intent1=new Intent(ContactInfoActivity.this,SendMessageActivity.class);
                intent1.putExtra(NAME_KEY,nameTextView.getText().toString());
                intent1.putExtra(NUMBER_KEY,numberTextView.getText().toString());
                startActivity(intent1);
            }
        });
    }
    public void initComponents(){
        nameTextView=findViewById(R.id.name_TextView);
        numberTextView=findViewById(R.id.number_TextView);
        buttonDelete=findViewById(R.id.btnDelete);
        buttonSendMessage=findViewById(R.id.btnSendMessage);
    }
}