package messenger.iti;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.telephony.SmsManager;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;
import android.widget.Toast;

public class SendMessageActivity extends AppCompatActivity {
  private String name,number;
  private TextView nameTextView,numberTextView;
  private EditText msgEditText;
  private Button sendNowButton,sendLaterButton;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_send_message);
       nameTextView=findViewById(R.id.name);
       numberTextView=findViewById(R.id.phoneee);
       msgEditText=findViewById(R.id.msg);
       sendLaterButton=findViewById(R.id.later);
       sendNowButton=findViewById(R.id.now);
        Intent intent=getIntent();
        name=intent.getStringExtra(ContactInfoActivity.NAME_KEY);
        number=intent.getStringExtra(ContactInfoActivity.NUMBER_KEY);
        numberTextView.setText(number);
        nameTextView.setText(name);
        sendNowButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                try{
                SmsManager smsManager=SmsManager.getDefault();
                   smsManager.sendTextMessage(number,null,msgEditText.getText().toString(),null,null);
                    Toast.makeText(SendMessageActivity.this, "Message sent", Toast.LENGTH_SHORT).show();



                }catch (Exception e){
                    Toast.makeText(SendMessageActivity.this, e.getMessage(), Toast.LENGTH_SHORT).show();
                }

            }
        });

    }
}