package messenger.iti.fragments;

import android.content.Intent;
import android.database.Cursor;
import android.os.Bundle;

import androidx.constraintlayout.widget.ConstraintLayout;
import androidx.fragment.app.Fragment;
import androidx.recyclerview.widget.DividerItemDecoration;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Toast;

import java.util.ArrayList;

import messenger.iti.AddingNumberActivity;
import messenger.iti.ContactInfoActivity;
import messenger.iti.R;
import messenger.iti.adapters.RecyclerViewAdapter;
import messenger.iti.helpers.DataBaseHelper;

public class ContactsFragment extends Fragment implements RecyclerViewAdapter.ListItemClickListener {
    private ConstraintLayout constraintLayout;
    private RecyclerView contactsRecyclerView;
    private Intent intent;
    private RecyclerViewAdapter recyclerViewAdapter;
    private DataBaseHelper dataBaseHelper;
   public ArrayList<String> nameList=new ArrayList<>();
   public ArrayList<String>numberList=new ArrayList<>();
    public static final String KEY_NAME="name";
    public static final String KEY_NUMBER="number";
    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container,
                             Bundle savedInstanceState) {
        // Inflate the layout for this fragment
        View view= inflater.inflate(R.layout.fragment_contacts, container, false);
        constraintLayout=view.findViewById(R.id.addContactConstraintLayout);
        contactsRecyclerView=view.findViewById(R.id.numbers_recycler_view);
        dataBaseHelper=new DataBaseHelper(getContext());
        constraintLayout.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                intent=new Intent(getContext(),AddingNumberActivity.class);
                getContext().startActivity(intent);
            }
        });
        showContacts();
        contactsRecyclerView.addItemDecoration(new DividerItemDecoration(getContext(), LinearLayoutManager.VERTICAL));
        contactsRecyclerView.setHasFixedSize(true);
        contactsRecyclerView.setLayoutManager(new LinearLayoutManager(getContext()));
        contactsRecyclerView.setAdapter(new RecyclerViewAdapter(nameList, numberList,  this));
        recyclerViewAdapter = new RecyclerViewAdapter(nameList, numberList, this);
        contactsRecyclerView.setAdapter(recyclerViewAdapter);
        return view;
    }
    public void showContacts(){
        if(dataBaseHelper.getAllData()==null) {
            Toast.makeText(getContext(), "No data", Toast.LENGTH_LONG).show();
        } else {
            Cursor res = dataBaseHelper.getAllData();
            if (res.getCount() == 0) {
                Toast.makeText(getContext(), "No data", Toast.LENGTH_LONG).show();
                return;
            }
            StringBuffer buffer ;
            StringBuffer buffer2 ;
            while (res.moveToNext()) {
               buffer=new StringBuffer();
               buffer2=new StringBuffer();
                buffer.append(res.getString(0));
                buffer2.append(res.getString(1));
                nameList.add(buffer.toString());
                numberList.add(buffer2.toString());
            }
        }
    }



    @Override
    public void onItemClick(View itemView, int position) {
        Intent intent=new Intent(getContext(), ContactInfoActivity.class);
        intent.putExtra(KEY_NAME,nameList.get(position));
        intent.putExtra(KEY_NUMBER,numberList.get(position));
        startActivity(intent);
    }
}